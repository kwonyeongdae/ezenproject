package com.ezen.spring.board.teampro.book;

import java.util.*;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface BookMapper 
{
	public List<Map<String,String>> searchByBook(Book key);
	public List<Map<String, String>> getList();
	public List<Map<String,String>> getallbook(); 
	public List<Map> search(Book vo);
}
