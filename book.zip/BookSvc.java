package com.ezen.spring.board.teampro.book;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BookSvc 
{
	@Autowired
	private BookDAO dao;

	public List<Book> getBook(int num) {
		
		return dao.getBook(num);
	}

	public Book getBookByNum(int num) {
		
		return dao.getBookByNum(num);
	}

	public Book getBookList() {
		
		return null;
	}

	public int getBookCount() {
	    return dao.getBookCount();
	}


	public List<Book> getBooksByPage(int pageNum, int pageSize) {
	    return dao.getBooksByPage(pageNum, pageSize);
	}


	
	/*
	public PageInfo<Book> getList(int pageNumber)
	{
		List<Book> list = new ArrayList<>();
		PageInfo<Map> pageInfo = dao.getList(pageNumber);
		List<Map> listMap = pageInfo.getList();
		
		for(int i=0;i<listMap.size();i++) {
			Map m = listMap.get(i);
			Book b = getBookIn(m);
			//b.setAttList(getAttachIn(m));
			list.add(b);
		}
		PageInfo<Book> pi = new PageInfo<>();
		pi.setList(list);
		//pi.setEndRow(pageInfo.getEndRow());
		//pi.setHasNextPage(pageInfo.isHasNextPage());
		//pi.setHasPreviousPage(pageInfo.isHasPreviousPage());
		//pi.setIsFirstPage(pageInfo.isIsFirstPage());
		//pi.setIsLastPage(pageInfo.isIsLastPage());
		//pi.setNavigateFirstPage(pageInfo.getNavigateFirstPage());
		//pi.setNavigateLastPage(pageInfo.getNavigateLastPage());
		pi.setNavigatepageNums(pageInfo.getNavigatepageNums());
		//pi.setNavigatePages(pageInfo.getNavigatePages());
		pi.setPageNum(pageInfo.getPageNum());
		return pi;
	}

	private Book getBookIn(Map m) 
	{
		int num = Integer.parseInt( m.get("num").toString());
		String bname = m.get("bname").toString();
		String author = m.get("author").toString();
		String publisher = m.get("publisher").toString();
		String introduce = m.get("introduce").toString();
		String price = m.get("price").toString();
		String img = m.get("img").toString();
		String pdate = null;
		
		Book b = new Book();
		b.setNum(num);
		b.setBname(bname);
		b.setAuthor(author);
		b.setPublisher(publisher);
		b.setPdate(pdate);
		b.setIntroduce(introduce);
		b.setPrice(price);
		b.setImg(img);
		return b;
	}
	
	*/
}
