package com.ezen.spring.board.teampro.book;

import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import lombok.extern.slf4j.Slf4j;


@Repository("bookdao")
@Slf4j
public class BookDAO {
	
	
	@Autowired
	private BookMapper bookMapper;
	
	private Connection rs;
	private Object pstmt;
	private Object conn;

	private Connection getConn() {
	    Connection conn = null;
	    String url = "jdbc:mysql://localhost:3306/test?characterEncoding=UTF-8&serverTimezone=UTC&SSL=false";
	    String username = "root";
	    String password = "ezenac";

	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	        conn = DriverManager.getConnection(url, username, password);
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    }
	    return conn;
	}

	
	
	public List<Book> getBook(int num) {
	    String sql = "SELECT * FROM book WHERE num = ?";
	    List<Book> bookList = new ArrayList<>();
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;

	    Connection conn = getConn();
	    try {
	        pstmt = conn.prepareStatement(sql);
	        pstmt.setInt(1, num);
	        rs = pstmt.executeQuery();

	        while (rs.next()) {
	            String bname = rs.getString("bname");
	            String publisher = rs.getString("publisher");
	            String author = rs.getString("author");
	            String price = rs.getString("price");
	            String pdate = rs.getString("pdate");
	            String img = rs.getString("img");
	            String introduce = rs.getString("introduce");

	            Book book = new Book();
	            book.setBname(bname);
	            book.setPublisher(publisher);
	            book.setAuthor(author);
	            book.setPrice(price);
	            book.setPdate(pdate);
	            book.setImg(img);
	            book.setIntroduce(introduce);
	            
	            bookList.add(book);
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    } finally {
	        closeAll();
	    }
	    return bookList;
	}

	private void closeAll() 
	{
	    try {
	        if (rs != null) rs.close();
			if(pstmt!=null) ((Connection) pstmt).close();
	        if(conn!=null) ((Connection) conn).close();
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    }
	}

	public Book getBookByNum(int num) {
	    List<Book> bookList = getBook(num);
	    for (Book book : bookList) {
	        if (book.getNum() == num) {
	            return book;
	        }
	    }
	    return null;
}



	public int getBookCount() {
	    String sql = "SELECT COUNT(*) FROM book";
	    int count = 0;

	    try (Connection conn = getConn();
	         PreparedStatement pstmt = conn.prepareStatement(sql);
	         ResultSet rs = pstmt.executeQuery()) {

	        if (rs.next()) {
	            count = rs.getInt(1);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return count;
	}

	public List<Book> getBooksByPage(int page, int pageSize) {
	    String sql = "SELECT * FROM book LIMIT ?, ?";
	    int offset = (page - 1) * pageSize;

	    List<Book> bookList = new ArrayList<>();

	    try (Connection conn = getConn();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {

	        pstmt.setInt(1, offset);
	        pstmt.setInt(2, pageSize);

	        try (ResultSet rs = pstmt.executeQuery()) {
	            while (rs.next()) {
	                Book book = new Book();
	                // 도서 정보를 ResultSet에서 읽어와서 Book 객체에 설정
	                bookList.add(book);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return bookList;
	}



	public PageInfo<Map> search(String category,String keyword, int pageNum)
	{
		PageHelper.startPage(pageNum,5);
		Book vo = new Book();
		if(category.equals("bname")) {vo.setBname(keyword);}
		else if(category.equals("publisher")) {vo.setPublisher(keyword);}
		else if(category.equals("author")) {vo.setAuthor(keyword);}
		
		PageInfo<Map> pageInfo = new PageInfo<>(bookMapper.search(vo));
		
		
		return pageInfo;
		
	}



	public PageInfo<Map> getallbook(int pageNum) {
		PageHelper.startPage(pageNum,5);
		PageInfo<Map> pageInfo = new PageInfo<> (bookMapper.getallbook());
		
		return pageInfo;
		
	}

}

/*
	public PageInfo<Map> search(String category, String keyword, int pageNum) 
	{
		PageHelper.startPage(pageNum, 10);
		
		Book key = new Book();
		if(category.equals("bname")) key.setBname(keyword);
		else if(category.equals("author")) key.setAuthor(keyword);
		else if(category.equals("introduce")) key.setIntroduce(keyword);
		
	
		PageInfo<Map> pageInfo = new PageInfo<>(bookMapper.searchByBook(key));
		return pageInfo;
	}



	public PageInfo<Map> getList(int pageNum) 
	{	
		PageHelper.startPage(pageNum, 10);
		PageInfo<Map> pageInfo = new PageInfo<>(bookMapper.getList());
		return pageInfo;
	}



}
	/*
	public Book getBookByNum(int num) {
		List<Book> bookList = getList();
	    for (Book book : bookList) {
	        if (book.getNum() == num) {
	            return book;
	        }
	}
		return null;
}
*/
