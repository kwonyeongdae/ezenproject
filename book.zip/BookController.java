package com.ezen.spring.board.teampro.book;

import java.util.*;  

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;


import com.github.pagehelper.PageInfo;


@Controller
@RequestMapping("/book")
public class BookController
{
	@Autowired
	private BookSvc svc;
	
	
	@Autowired
	@Qualifier("bookdao")
	private BookDAO bookDAO;
	
	
	@GetMapping("/")
	public String index()
	{
		return "book/index";	
	}

	@GetMapping("/cart")
	public String cart()
	{
		return "book/cart";
	}
	
	@GetMapping("/add")
	public String add()
	{
		return "book/addform";
	}
	
	@GetMapping("/animal")
	public String animal()
	{
		return "book/animal";
	}
	
	@GetMapping("/princess")
	public String princess()
	{
		return "book/princess";
	}
	
	@GetMapping("/prince")
	public String prince()
	{
		return "book/prince";
	}
	
	@GetMapping("/korea")
	public String korea()
	{
		return "book/korea";
	}
	
	
	@GetMapping("/list/page/{pn}")
	public String list(@PathVariable("pn") int pageNum,
	                   @RequestParam(value = "category", required = false) String category,
	                   @RequestParam(value = "keyword", required = false) String keyword, Model model) {
	    PageInfo<Map> pageInfo = null;
	    if (category != null) {
	        pageInfo = bookDAO.search(category, keyword, pageNum);
	        model.addAttribute("category", category);
	        model.addAttribute("keyword", keyword);
	    } else {
	        pageInfo = bookDAO.getallbook(pageNum);
	    }
	    model.addAttribute("pageInfo", pageInfo);

	    return "book/blist";
	}




	
	@GetMapping("/list/page/2")
	public String list2() 
	{	
		return "book/blist2";
	}
	
	
	@GetMapping("/list/page/3")
	public String list3() 
	{
		return "book/blist3";
	}

	
	@GetMapping("/detail/{num}")
	public String detail(@PathVariable int num ,Model model)
	{
		Book book = svc.getBookByNum(num);
		model.addAttribute("list",svc.getBook(num));
		return "book/detail";
	}
	
	   @PostMapping("/add")
	   @ResponseBody
	    public Map<String, Object> addBook(Model model,MultipartFile image, String bname, String author, String publisher,String pdate,String price) 
	   {
	        // 여기서부터는 전달받은 정보를 활용하여 도서 정보를 저장하는 로직을 구현합니다.
	        // 이 예시에서는 간단히 도서 정보를 출력하기만 하겠습니다.

	        System.out.println("도서명: " + bname);
	        System.out.println("저자: " + author);
	        System.out.println("출판사: " + publisher);
	        System.out.println("출판일: " + pdate);
	        System.out.println("가격:" + price);

	        // 이미지 파일 업로드를 원하면 아래와 같이 처리할 수 있습니다.
	        if (image != null && !image.isEmpty()) {
	            // 여기서 이미지를 저장하거나 다른 처리를 수행합니다.
	            System.out.println("이미지 파일 업로드 완료: " + image.getOriginalFilename());
	        }

	        model.addAttribute("price",price);
	        model.addAttribute("title",bname);
	        // 처리 결과를 클라이언트에게 응답합니다.
	        Map<String, Object> response = new HashMap<>();
	        response.put("added", true);
	        response.put("message", "도서 정보 저장 성공");
	        return response;
	    }
	
	/*
	@GetMapping("/book/list/page/{pn}")
	public String getList(@PathVariable int pn, 
							@RequestParam(value="category", required=false) String category,
							@RequestParam(value="keyword", required=false) String keyword,
							Model model)
	{
		PageInfo<Map> pageInfo = null;
		if(category!=null) { //검색결과 목록
			pageInfo = bookDAO.search(category, keyword,pn);
			model.addAttribute("category", category);
			model.addAttribute("keyword", keyword);
		}else {  //검색 아닌 일반 목록
			pageInfo = bookDAO.getList(pn);
		}
		model.addAttribute("pageInfo", pageInfo);
		return "book/index";
	}
	*/
}
