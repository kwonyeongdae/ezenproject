-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `boughtbook`
--

DROP TABLE IF EXISTS `boughtbook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boughtbook` (
  `bnum` int NOT NULL,
  `userid` varchar(40) NOT NULL,
  `bname` varchar(45) NOT NULL,
  `quantity` int NOT NULL,
  `price` int NOT NULL,
  `cvrimg` varchar(45) NOT NULL,
  `beyday` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boughtbook`
--

LOCK TABLES `boughtbook` WRITE;
/*!40000 ALTER TABLE `boughtbook` DISABLE KEYS */;
INSERT INTO `boughtbook` VALUES (1,'admintest21','디즈니 메이의 새빨간 비밀 무비동화',2,19000,'','2023-07-21'),(5,'admintest21','케이블루의 두 번째 동화 같은 자수 이야기',2,32400,'','2023-07-24'),(6,'admintest21','알쏭달쏭 캐치! 티니핑 마음을 여는 동화 4: 치료해 줄게, 삐뽀!',2,21600,'','2023-07-24'),(7,'admintest21','어린 왕자, 진짜 중요한 건 눈에 보이지 않아',2,20700,'','2023-07-24'),(5,'admintest21','케이블루의 두 번째 동화 같은 자수 이야기',16200,2,'팜파스.jpg','2023-07-24'),(6,'admintest21','알쏭달쏭 캐치! 티니핑 마음을 여는 동화 4: 치료해 줄게, 삐뽀!',10800,1,'뽀삐.jpg','2023-07-24'),(5,'admintest21','케이블루의 두 번째 동화 같은 자수 이야기',16500,1,'팜파스.jpg','2023-07-24'),(5,'admintest21','케이블루의 두 번째 동화 같은 자수 이야기',1,16500,'팜파스.jpg','2023-07-24');
/*!40000 ALTER TABLE `boughtbook` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-24 17:08:12
