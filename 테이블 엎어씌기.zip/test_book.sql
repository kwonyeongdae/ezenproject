-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book` (
  `bnum` int NOT NULL AUTO_INCREMENT,
  `bname` varchar(100) NOT NULL,
  `publisher` varchar(45) NOT NULL,
  `author` varchar(100) NOT NULL,
  `price` int NOT NULL,
  `pdate` varchar(45) NOT NULL,
  `content` varchar(1500) NOT NULL,
  `cvrimg` varchar(45) NOT NULL,
  `cate` varchar(45) NOT NULL,
  `fsize` decimal(5,2) NOT NULL,
  `contenttype` varchar(45) NOT NULL,
  PRIMARY KEY (`bnum`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book`
--

LOCK TABLES `book` WRITE;
/*!40000 ALTER TABLE `book` DISABLE KEYS */;
INSERT INTO `book` VALUES (5,'케이블루의 두 번째 동화 같은 자수 이야기','팜파스','김소영',16500,'2021년 04월 15일','이야기가 있는 프랑스 자수로 아름다운 작품을 선보이는 케이블루의 《케이블루의 두 번째 동화 같은 자수 이야기》를 소개합니다. 《케이블루의 동화 같은 프랑스 자수》를 펴낸 후 6년 만에 더 아름다운 자수 이야기를 전하고 있습니다. 빛나는 계절과 꽃, 동물과 아이를 사랑하는 작가의 마음이 고스란히 전해지는 이 책은 몸과 마음이 지친 당신에게 따뜻한 위로를 전합니다.','팜파스.jpg','a',58.00,'image/jpeg'),(6,'알쏭달쏭 캐치! 티니핑 마음을 여는 동화 4: 치료해 줄게, 삐뽀!','휴먼큐','아이언휴먼 편집부',10800,'2023년06월29일','폭발적인 인기를 끈 〈캐치! 티니핑〉과 〈반짝반짝 캐치! 티니핑〉에 이어 2022년 9월 〈알쏭달쏭 캐치! 티니핑〉이 역대 시리즈 중 최고 시청률을 기록하며 화려하게 막을 열었습니다. 새로운 모습으로 등장한 로미와 하츄핑은 더욱더 용감하고 따듯하게 어린이들을 격려하고 위로합니다. 지금까지와는 다른 수수께끼를 품고 등장한 열쇠 티니핑들은 때로는 순수하고 때로는 짓궂게 변하는 어린이들의 마음처럼 다양한 모습으로 어린이들의 깊은 공감을 불러일으킵니다. 특히 로열 티니핑 하츄핑과 꾸래핑, 나나핑과 솔찌핑이 보여 주는 사랑과 다정함, 열정과 솔직함은 어린이들이 친구를 사귀며 성장하는 데 가장 중요한 마음입니다. 이런 마음은 소중한 친구 제니를 되찾기 위해 노력하는 로미와 흩어진 열쇠 티니핑 친구들을 찾는 로열 티니핑들의 이야기를 통해 감동적으로 다가옵니다. 어린이들은 로미와 로열 티니핑들의 좌충우돌 모험을 함께하며 친구를 소중히 대하고 양보하는 마음, 다정함, 열정과 용기, 그리고 솔직함을 배우며 성장합니다.\r\n아이휴먼이 펴내는 『알쏭달쏭 캐치! 티니핑 마음을 여는 동화』 시리즈는 이런 〈알쏭달쏭 캐치! 티니핑〉의 에피소드를 동화로 재구성해 어린이들의 마음을 사로잡은 것은 물론, 어린이들이 여러 상황에서 느낄 수 있는 다양한 감정을 깊이 이해하며 바른 마음을 기를 수 있도록 인성 요소까지 담았습니다. 이번 『알쏭달쏭 캐치! 티니핑 마음을 여는 동화 ④ 치료해 줄게, 삐뽀!』는 애니메이션의 5화와 6화를 엮은 그림책으로, 실제 방송 화면을 그대로 담은 생생한 그림이 아이들의 흥미와 상상력을 자극합니다. 이야기를 모두 읽은 뒤에는 ‘알쏭달쏭 마음 열기 수업’에서 이야기 속에 담긴 인성의 핵심 주제인 ‘병원’의 중요성에 대해 되새길 수 있습니다. 또한 주인공 티니핑들과 함께하는 ‘치료 도구 찾기’ 놀이 활동으로 치료 도구에 친숙해지고, ‘알쏭달쏭 수수께끼 타임’으로 이야기를 돌아보며 마지막까지 재미있게 책을 즐길 수 있습니다. 아이들에게 TV 애니메이션의 감동을 생생하게 느끼며 내 몸과 마음을 깊게 이해하고 성장하는 기쁨을 선물해 주세요!','뽀삐.jpg','b',59.00,'image/jpeg'),(7,'어린 왕자, 진짜 중요한 건 눈에 보이지 않아','은행나무','김서영',10350,' 2018년 06월 12일','따뜻하고 과학적인 글을 꾸준히 발표해온 김서영 교수와 그의 제자들이 함께 쓴 책 『어린 왕자, 진짜 중요한 건 눈에 보이지 않아』가 은행나무출판사에서 출간됐다. 부제 \'어린 왕자 심리 수업\'에서 알 수 있듯이 심리 이론을 매개로 어른이 되어 다시 읽은 『어린 왕자』해설서이다. 광운대학교에서 수차례 우수강의상, 최고교수상, 최고교수대상을 받은 김서영 교수의 교양 강의 프로젝트를 담았다. 통찰력이 빛나는 학생들과, 학생들과 교감을 나누는 선생님이 만나 전에 없던 『어린 왕자』 이야기를 들려준다. 끈끈한 정서적 유대감 속에서 열 번의 강의와 한 번의 토론 형식으로 이뤄진 이 특별한 프로젝트 자체가 집단 심리 치료의 현장이라 해도 전혀 무리는 아니다. 참신한 해설을 제시하는 학생들과 이를 학문적으로 풀어내는 김서영 교수의 대화를 따라가노라면 가르치는 자와 배우는 자의 경계가 허물어지고 내 안에 있는 나 이상의 것을 발견하는 지극한 기쁨을 느낄 수 있다. 이해 불가능함을 고백하고 서로의 말에 귀를 기울일 때 비로소 드러나는 보이지 않는 것들을 『어린 왕자』 속에서 포착해낸다.','asd.jpg','c',31.00,'image/jpeg');
/*!40000 ALTER TABLE `book` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-07-24 17:08:12
