package com.ezen.spring.board.teampro;
  
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;
import com.ezen.spring.board.teampro.MemberVO;
    
@Component("fairyMapper")
@Mapper
public interface FairyMapper 
{  
	public int addfairyMem(MemberVO mem);

	public int joinIdCheck(MemberVO mem);

	public int joinEmailCheck(MemberVO mem);

	public int loginCheck(MemberVO mem);

	public MemberVO getJoinedMem(String uid);

	public int adminLoginCheck(MemberVO mem);

	public int updatedMem(MemberVO mem); 
	
	
}
