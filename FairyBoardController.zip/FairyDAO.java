package com.ezen.spring.board.teampro;
     
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import com.ezen.spring.board.teampro.MemberVO;
      
@Repository("fairydao")
public class FairyDAO 
{
    //@Autowired
    //private MemberIO io; 
      
    @Autowired
    @Qualifier("fairyMem")
    private MemberVO memvo;
    
    @Autowired
    @Qualifier("fairyMapper")
    private FairyMapper fairyMapper;
	
	public boolean addJoin(MemberVO mem) 
	{
	    return fairyMapper.addfairyMem(mem)>0;
	}

	public boolean joinIdCheck(MemberVO mem) 
	{
		
		return fairyMapper.joinIdCheck(mem)>0;
	}

	public boolean joinEmailCheck(MemberVO mem) 
	{
		
		return fairyMapper.joinEmailCheck(mem)>0;
	}

	public boolean login(MemberVO mem) 
	{
	
		return fairyMapper.loginCheck(mem)>0;
	}

	public MemberVO getJoinedMem(String uid) 
	{
		return fairyMapper.getJoinedMem(uid);
	}

	public boolean adminLogin(MemberVO mem) 
	{
		return fairyMapper.adminLoginCheck(mem)>0;
	}

	public Boolean updatedMem(MemberVO mem)
	{
		
		return fairyMapper.updatedMem(mem)>0;
	}

		
	

}
