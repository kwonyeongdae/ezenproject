package com.ezen.spring.board.teampro;
           
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.ezen.spring.board.teampro.MemberVO;

import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j; 
           
@Controller
@RequestMapping("/fairy")
@SessionAttributes("userid")
@Slf4j
public class FairyBoardController 
{  
  @Autowired
  @Qualifier("fairyMem")
  private MemberVO memvo;   
  
  //@Autowired
  //private FairyService svc;
  
  @Autowired
  @Qualifier("fairydao")
  private FairyDAO fairydao;
  
  @GetMapping("/")
  public String index()
  {
	  return "fairy/index";
  }
  
  @GetMapping("/joinForm")
  public String joinForm()
  {
	  return "fairy/joinForm";
  }
  
  @PostMapping("/join")
  @ResponseBody 
  public Map<String, Boolean> addJoin(MemberVO mem)
  {
	  Map<String, Boolean> map = new HashMap();
	  map.put("addedJoin", fairydao.addJoin(mem));
	  return map;
	  
  }
  
  @GetMapping("/join")
  @ResponseBody 
  public Map<String, Boolean> joinCheck(MemberVO mem)
  {
	  Map<String, Boolean> map = new HashMap();
	  map.put("isDuplicateId", fairydao.joinIdCheck(mem));
	  map.put("isDuplicateEmail", fairydao.joinEmailCheck(mem));
	  return map;
  }
  
  
  @GetMapping("/login")
  public String login()
  {
	  return "fairy/loginForm";
  }
  

  @GetMapping("/adminLogin")
  public String Adminlogin()
  {
	  return "admin/adminLogin";
  }
  
   
  @PostMapping("/login")
  @ResponseBody 
  public Map<String, Boolean> login(MemberVO mem, Model model)
  {
	  boolean login = fairydao.login(mem);
	  if(login){
		  model.addAttribute("userid", mem.getUserid());
	  }
	  Map<String, Boolean> map = new HashMap<>();
	  map.put("login", login);
	  return map;
  }
  
  
  @PostMapping("/adminLogin")
  @ResponseBody 
  public Map<String, Boolean> adminlogin(MemberVO mem, HttpSession session) 
  {
      boolean adminLogin = fairydao.adminLogin(mem);
      if (adminLogin) {
    	  session.setAttribute("userid", mem.getUserid());
          session.setAttribute("isAdmin", true); // 관리자 권한인 경우 세션에 isAdmin 속성을 true로 저장
         }
      Map<String, Boolean> map = new HashMap<>();
      map.put("adminLogin", adminLogin);
      return map;
  }
  

  @GetMapping("/admin")
  public String admin()
  {
	  return "admin/admin";
  }
  
  @GetMapping("/editMem/{userid}")
  public String editMember(@PathVariable String userid, Model model)
  {
	  MemberVO mem = fairydao.getJoinedMem(userid);
	  model.addAttribute("member", mem);
	  //model.addAttribute("userid", userid);
	  return "fairy/editMember";
  }
  
  @PostMapping("/updateMem/{userid}")
  @ResponseBody 
  public Map<String, Boolean> updateMember(@PathVariable String userid, MemberVO mem)
  {
	  log.info("userid={}", userid);
	  log.info("mem={}", mem);
	  Map<String, Boolean> map = new HashMap();
	  mem.setUserid(userid);
	  map.put("updated", fairydao.updatedMem(mem));
	  map.put("isDuplicateEmail", fairydao.joinEmailCheck(mem));
	  return map;
  }
  
  //일반 이용자 로그아웃 
  @GetMapping("/logout")
  @ResponseBody
  public Map<String, Boolean> logout(SessionStatus status)
  { 
	  Map<String, Boolean> map = new HashMap<>();
	  status.setComplete();
	  map.put("logout", true);
	  return map;
  }
   
  //관리자 로그아웃
  @GetMapping("/adminLogout")
  @ResponseBody
  public Map<String, Boolean> adminLogout(HttpSession session) 
  {
      Map<String, Boolean> map = new HashMap<>();
      //session.removeAttribute("isAdmin"); // 세션에서 "isAdmin" 속성을 제거.
      session.invalidate(); // 세션을 무효화합니다
      /*session.removeAttribute("userid");
      session.removeAttribute("isAdmin");*/
      map.put("logout", true);
      return map;
  }
  
  
}

 

