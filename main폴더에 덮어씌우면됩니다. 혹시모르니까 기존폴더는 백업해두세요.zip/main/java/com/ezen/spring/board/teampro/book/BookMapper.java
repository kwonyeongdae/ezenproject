package com.ezen.spring.board.teampro.book;

import java.util.*;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

import com.ezen.spring.board.teampro.cart.BookVO;

@Component("bookmapper")
@Mapper
public interface BookMapper {
	
	public int addbook(Book bo);
	
	public List<Map<String,String>> getallbook(); 
	
	public List<Map> search(Book vo);
	
	public List<Book> CateSearch(String cate);

	public Book getbook(int bnum);
	
	public int getdelete(int bnum);
}
