package com.ezen.spring.board.teampro.login;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.ezen.spring.board.teampro.admin.AdminVO;
import com.ezen.spring.board.teampro.login.MemberVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/fairy")
@SessionAttributes("userid")
public class FairyBoardController 
{
  @Autowired
  @Qualifier("fairyMem")
  private MemberVO memvo;
 
  
  @Autowired
  @Qualifier("fairydao")
  private FairyDAO fairydao;
  
  @GetMapping("/")
  public String index(Model model,@SessionAttribute(name = "userid", required = false)String userid)
  {
	  model.addAttribute("user",fairydao.getJoinedMem(userid));
	  return "fairy/index";
  }
  
  @GetMapping("/joinForm")
  public String joinForm(Model model,@SessionAttribute(name = "userid", required = false)String userid)
  {
	  model.addAttribute("user",fairydao.getJoinedMem(userid));
	  return "fairy/joinForm";
  }
  
  @PostMapping("/join")
  @ResponseBody 
  public Map<String, Boolean> addJoin(MemberVO mem)
  {
	  Map<String, Boolean> map = new HashMap();
	  map.put("addedJoin", fairydao.addJoin(mem));
	  return map;
	  
  }
  
  @GetMapping("/join")
  @ResponseBody 
  public Map<String, Boolean> joinCheck(MemberVO mem)
  {
	  Map<String, Boolean> map = new HashMap();
	  map.put("isDuplicateId", fairydao.joinIdCheck(mem));
	  map.put("isDuplicateEmail", fairydao.joinEmailCheck(mem));
	  return map;
  }
  
  
  @GetMapping("/login")
  public String login()
  {
	  return "fairy/loginForm";
  }
  
  @PostMapping("/login")
  @ResponseBody 
  public Map<String, Boolean> login(@RequestParam("userid") String userid, HttpSession session,MemberVO mem, Model model)
  {
	 MemberVO vo =  fairydao.getJoinedMem(userid);
     boolean login = fairydao.login(mem);
     if(login){
    	 session.setAttribute("userid", vo.getUserid());
         model.addAttribute("uid", vo.getUserid());
         session.setAttribute("isAdmin", vo.getNumber());
        
     }
     System.out.println("여기 = " +vo.getNumber());
     System.out.println("여기 = " +vo.getUserid());
     Map<String, Boolean> map = new HashMap<>();
     map.put("login", login);
     return map;
  }
  
  
  @GetMapping("/editMem/{userid}")
  public String editMember(@PathVariable String userid, Model model)
  {
	  MemberVO mem = fairydao.getJoinedMem(userid);
	  model.addAttribute("member", mem);
	  return "fairy/editMember";
  }
  
   
  @GetMapping("/logout")
  @ResponseBody
  public Map<String, Boolean> logout(SessionStatus status)
  { 
	  Map<String, Boolean> map = new HashMap<>();
	  status.setComplete();
	  map.put("logout", true);
	  return map;
  }
  @GetMapping("/mypage/{userid}")
  public String Mypage(@PathVariable String userid,Model model) {
	  MemberVO vo = fairydao.getJoinedMem(userid);
	  List<AdminVO> bougth = fairydao.getBought(userid);
	  model.addAttribute("member",vo);
	  model.addAttribute("book",bougth);
	  return "fairy/mypage";
	  
  }
  
  @GetMapping("/adminLogin")
  public String Adminlogin()
  {
     return "admin/adminLogin";
  }
 


  @PostMapping("/adminLogin")
  @ResponseBody
  public Map<String, Boolean> adminlogin(MemberVO mem, HttpSession session)
  {
      boolean adminLogin = fairydao.adminLogin(mem);
      if (adminLogin) {
         session.setAttribute("userid", mem.getUserid());
          session.setAttribute("isAdmin", true); // 관리자 권한인 경우 세션에 isAdmin 속성을 true로 저장
         }
      Map<String, Boolean> map = new HashMap<>();
      map.put("adminLogin", adminLogin);
      return map;
  }


  @GetMapping("/admin")
  public String admin()
  {
     return "admin/admin";
  }

  @PostMapping("/updateMem/{userid}")
  @ResponseBody
  public Map<String, Boolean> updateMember(@PathVariable String userid, MemberVO mem)
  {
     
     Map<String, Boolean> map = new HashMap();
     mem.setUserid(userid);
     map.put("updated", fairydao.updatedMem(mem));
     map.put("isDuplicateEmail", fairydao.joinEmailCheck(mem));
     return map;
  }



//관리자 로그아웃
  @GetMapping("/adminLogout")
  @ResponseBody
  public Map<String, Boolean> adminLogout(HttpSession session)
  {
      Map<String, Boolean> map = new HashMap<>();
      session.removeAttribute("userid");
      session.removeAttribute("isAdmin");
      map.put("logout", true);
      return map;
  }
  
  @GetMapping("/memlist")
  public String getlist(Model model)
  {
      List<MemberVO> mlist = fairydao.getmemlist();
      model.addAttribute("mlist",mlist);
      return "thymeleaf/memlist";
  }
  @GetMapping("/emplist")
  public String emplist(Model model)
  {
      List<MemberVO> mlist = fairydao.getmemlist();
      model.addAttribute("emplist",mlist);
      return "thymeleaf/emplist";
  }
  
  @PostMapping("delemp")
  @ResponseBody
  public Map<String,Boolean> delemp(@RequestParam int fnum){
	 Map<String,Boolean> map = new HashMap<>();
	 System.out.println("fnum받는곳 = " + fnum);
	 boolean del = fairydao.Escemp(fnum);
	 map.put("del", del);
	 return map;
	  
  }
}

 

