package com.ezen.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service//서비스 클래스를 부품처럼 쓰겟다는 뜻
public class GuguSVC 
{
	public List<String> getGugu(int dan)
	{
		List<String> g = new ArrayList<>();
	       for (int i = 1; i <= 9; i++) {
	           g.add(String.format("%dx%d=%d", dan, i, dan * i));
	       }
		return g;
		
	}
}
