package com.ezen.spring.user;

import java.util.Objects;

public class UserVO {
	String uid;
	
	String pwd;
	
	
	public UserVO() {}
	public UserVO(String uid, String pwd) {
		super();
		this.uid = uid;
		this.pwd = pwd;
	}
	
	
	public UserVO(String line) {
        String[] parts = line.split(" ");
        if (parts.length == 2) {
            this.pwd = parts[0];
            this.uid = parts[1];
        }
    }
	@Override
	public boolean equals(Object obj) {
		UserVO other = (UserVO) obj;
		return Objects.equals(pwd, other.pwd) && Objects.equals(uid, other.uid);
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	
}
