package com.ezen.spring.user;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.ezen.spring.empfile.EmpVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
@Service
@Component
public class UserSVC {
	@Autowired
	UserIO io;
	
	public boolean login(UserVO vo)
	{
	
		io.login(vo);
		return true;
	}
	//============================================================================================	
	
}
